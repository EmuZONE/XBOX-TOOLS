Hello,

Thank you for downloading this phpBB 3.2 Theme called "pycode".
It is a minimalistic dark style theme, made for myself and shared with the phpBB Community. 
Features custom made forum and topic icons. Few modifications for template files.
For administrators group color I used #FF9832.
For super moderators group color I used #00A15E.
You can use your own color schemes.
Theme will be updated if any bugs are found.
For any questions you can contact me at danceban@outlook.com
If you like this theme, you can star it at my www.github.com/danceban

You can support or buy me a drink by donating a dollar at https://www.paypal.me/danceban